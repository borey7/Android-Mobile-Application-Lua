local composer = require("composer")
composer.setVariable("hSave", "")
composer.setVariable("wSave", "")
composer.gotoScene("scene1")